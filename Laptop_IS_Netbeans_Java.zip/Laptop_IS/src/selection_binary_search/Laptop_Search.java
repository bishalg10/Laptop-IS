/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selection_binary_search;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Laptop_Search {
    String laptopID, manufacturer, color, ram,ssd, basic,weight;        //declaring instance variable
    int price;                                                          //declaring instance variable
    
    //Laptop_Search(){}
    /*
    *Laptop_Search is a construtor method.
    *Attributes such as manufacturer,color,graphic,price,ram,ssd,basic and weight are initialize here of class DataModel.
    */
    
    public Laptop_Search(String laptopID,String manufacturer, String color, int price, String ram,String ssd, String basic,String weight){ //declaring local variables
        //invoking constructor name
        this.laptopID=laptopID;
        this.manufacturer = manufacturer;           
        this.color = color;
        this.price = price;
        this.ram=ram;
        this.ssd=ssd;
        this.basic=basic;
        this.weight=weight;  
    }
    
    /*
    *Accessor methos that returns the value of
    *manufacturer,color,graphic,price,ram,ssd,basic and weight
    */
    public String getlaptopID(){
        return laptopID;                                //Returns the method getlaptopID.
    }
    public String getmanufacturer(){
        return manufacturer;                            //Returns the method getmanufacturer.
    }
    public String getcolor(){
        return color;                                   //Returns the method getcolor.
    }
    public int getprice(){
        return price;                                   //Returns the method getprice.
    }
    public String getram(){
        return ram;                                     //Returns the method getram.
    }
    public String getssd(){
        return ssd;                                     //Returns the method getssd.
    }
    public String getbasic(){
        return basic;                                   //Returns the method getbasic.
    }
    public String getweight(){
        return weight;                                  //Returns the method getweight.
    }

    /*
    *Method for implementing selection sort.
    *For arranging the data of arraylist in ascending order according to price.
    */
    
    public static void sort(ArrayList<Laptop_Search> list){
        int max,i,j;
        Laptop_Search temp;
        //Moves boundary of unsorted subarray one by one.
        for(i=0;i<list.size()-1;i++){
            max = i;           //Find minimum element in unsorted array.                        
            for(j=i+1; j<list.size();j++){
                if(list.get(j).getprice()<(list.get(max).getprice()))
                {
                    max =j;      //Swap the found minimum element with first element.
                }
            }
            temp =list.get(i);
            list.set(i,list.get(max));
            list.set(max,temp);
        }
    }

    public static int binarySearch(ArrayList<Laptop_Search> list, int low, int high, int key){
    /*
        *A binary search function.It returns location of key.
        *Location of key in array "list" in given array.
        *otherwise -1.
         */
         if (low <= high){
            int mid = (low + high) / 2;
                int midval=list.get(mid).getprice();
                //If element is present in middle.
                if (midval == key){
                    return mid;
                //If midval is greater than key, 
                //then the element can only be present in left array.    
                }else if (midval > key){                         
                    return binarySearch(list, low, mid-1,key);
                //Else the element is present in right array.
                }else{
                    return binarySearch(list,  mid+1, high, key);
                }
            //We reach here when element is not present in  the array.    
            }else{
                return -1;
            }
        }  
}
    

